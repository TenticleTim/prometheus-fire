# Installing Thesmos Agents in Cursor

Each .mdc file in this folder is a Cursor rule file.

## How to install

1. In your project root, create: .cursor/rules/
2. Copy the .mdc files you want into .cursor/rules/
3. Cursor loads them automatically — no restart needed

## Quick install (all agents)

cp *.mdc /path/to/your/project/.cursor/rules/

## Per-agent install

Each .mdc file has alwaysApply: false by default. Agents activate when
you mention their domain or explicitly call them in Cursor Chat.

Learn more: https://docs.cursor.com/context/rules-for-ai
