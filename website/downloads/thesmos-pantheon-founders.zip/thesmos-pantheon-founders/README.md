# Thesmos Pantheon — Founders Pack

A curated council of **16 gods** hand-picked for startup founders — strategy, sales, fundraising, product, and the legal/security guardrails around them —
orchestrated by Zeus, deployable into every major AI platform.

## What's inside

Each platform folder contains the agents in that platform's native format,
plus an INSTALL.md with step-by-step setup. Start with the folder matching
your AI tool (Claude Code recommended), and always install Zeus first —
he routes every task to the right specialist automatically.

## Want the full Pantheon?

The complete 66-god Pantheon (every domain, all platforms, VS Code extension)
is available at https://holley.studio/thesmos

---

Thesmos Pantheon · © Holley Studio. All rights reserved.
