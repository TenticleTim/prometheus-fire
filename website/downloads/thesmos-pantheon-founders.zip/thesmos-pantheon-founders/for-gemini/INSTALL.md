# Installing Thesmos Agents as Gemini Gems

Each .txt file in this folder contains instructions for one Gemini Gem.
Gemini runs ONE Gem per conversation — there is no in-chat multi-agent routing.
Install the Zeus Receptionist to get theatrical routing between your Gems.

## Start here: the Zeus Receptionist

1. Go to https://gemini.google.com/gems/new
2. Paste the contents of zeus-receptionist-gemini.txt into "Instructions"
3. Name it "Zeus — Pantheon Receptionist" and save
4. Bring any task to Zeus first — he identifies the right god, sharpens your
   prompt, and tells you which Gem to open

## Installing the god Gems

1. Create a New Gem
2. Paste the agent's .txt file into "Instructions"
3. Name it after the agent (e.g. "Argus — Security Agent") and save

NOTE: If a Gem's instructions field truncates the file (some accounts enforce
shorter limits), paste the file up to and including the "## Anti-Drift Protocol"
section header, then the protocol itself — identity and expertise survive.

Learn more: https://support.google.com/gemini/answer/14949803
