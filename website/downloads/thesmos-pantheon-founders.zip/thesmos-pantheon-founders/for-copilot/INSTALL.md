# Installing Thesmos Agents with GitHub Copilot

Each .md file in this folder contains instructions for GitHub Copilot.

## How to install

1. Open your project's .github/copilot-instructions.md
   (Create it if it doesn't exist)
2. Open the .md file for the agent you want
3. Copy the agent instructions and paste them into copilot-instructions.md

## Multi-agent setup

You can combine multiple agents in copilot-instructions.md. Each agent's
section is separated by a horizontal rule. We recommend starting with Zeus
to enable orchestration, then adding the specialists you need most.

## VS Code Custom Instructions

Alternatively, in VS Code:
1. Open Settings (Cmd/Ctrl + ,)
2. Search for "GitHub Copilot: Instructions"
3. Paste agent instructions directly

Learn more: https://docs.github.com/en/copilot/customizing-copilot/adding-repository-custom-instructions-for-github-copilot
