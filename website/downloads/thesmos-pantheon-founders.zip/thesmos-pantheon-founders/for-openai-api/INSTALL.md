# Thesmos Agents via the OpenAI Assistants API

Each .json file is a ready-to-create assistant definition (name, instructions,
model, metadata).

## Create an assistant with curl

curl https://api.openai.com/v1/assistants \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -H "OpenAI-Beta: assistants=v2" \
  -d @argus-security-agent-openai-assistant.json

## Or with the openai SDK (Node)

import OpenAI from 'openai';
import { readFileSync } from 'node:fs';
const openai = new OpenAI();
const def = JSON.parse(readFileSync('argus-security-agent-openai-assistant.json', 'utf8'));
const assistant = await openai.beta.assistants.create(def);

Learn more: https://platform.openai.com/docs/assistants
