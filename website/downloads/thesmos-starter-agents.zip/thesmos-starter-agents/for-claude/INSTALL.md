# Installing Thesmos Agents in Claude Code

Each .md file in this folder is an agent definition for Claude Code.

## How to add an agent

1. In your project root, create a directory: .claude/agents/
2. Copy the .md files you want into .claude/agents/
3. Restart Claude Code — the agents will appear automatically

## Quick install (all agents)

cp *.md /path/to/your/project/.claude/agents/

## Individual agent install

cp zeus-executive-agent.md /path/to/your/project/.claude/agents/

Claude Code will discover and load agents from .claude/agents/ automatically.
The agent name shown in the UI matches the filename (without the .md extension).

Learn more: https://docs.anthropic.com/claude-code/agents
