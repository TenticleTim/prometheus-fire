# Installing Thesmos Agents as Gemini Gems

Each .txt file in this folder contains instructions for one Gemini Gem.

## How to create a Gem

1. Go to https://gemini.google.com/gems/new
2. Click "New Gem" or "Create a Gem"
3. Open the .txt file for the agent you want
4. Copy the entire contents into the "Instructions" field
5. Give the Gem the agent's name (e.g. "Ares — Sales Agent")
6. Click "Save"

## Tips

- Gems are private by default
- You can create as many Gems as your plan allows
- Use the Zeus Gem to orchestrate the full Pantheon

Learn more: https://support.google.com/gemini/answer/14949803
